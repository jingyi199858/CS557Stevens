import nltk
from nltk import pos_tag, word_tokenize
from nltk.tokenize import sent_tokenize
from nltk.book import *
from nltk.tokenize.treebank import TreebankWordDetokenizer

booklist = [text1,text2,text3,text4,text5,text6,text7,text8,text9]
longest = []

for i in booklist:
    text_to = TreebankWordDetokenizer().detokenize(i)
    longest.append(max(sent_tokenize(text_to), key=len))

for i in longest:
    print(len(i))


print(len(max(longest, key=len)), max(longest, key=len))

"""
We have found the longest sentence among all the texts.
Tokenize the longest sentence and tag all the words.
"""
longestsent = word_tokenize(max(longest, key=len))
print(pos_tag(longestsent))
default_tagger = nltk.DefaultTagger('NN')
print(default_tagger.tag(longestsent))
patterns = [
(r'.*ing$', 'VBG'),                # gerunds
(r'.*ed$', 'VBD'),                 # simple past
(r'.*es$', 'VBZ'),                 # 3rd singular present
(r'.*ould$', 'MD'),                # modals
(r'.*\'s$', 'NN$'),                # possessive nouns
(r'.*s$', 'NNS'),                  # plural nouns
(r'^-?[0-9]+(\.[0-9]+)?$', 'CD'),  # cardinal numbers
(r'.*', 'NN')                      # nouns (default)
]
regexp_tagger = nltk.RegexpTagger(patterns)
print(regexp_tagger.tag(longestsent))

"""
report:
Two taggers got compared in this example: default tagger and regular expression tagger.
The default tagger is performing completely bad because it only follows the tag that is assigned.
the regular expression tagger performs much better than previous one, but still needs to be improved 
based on the capacity of regular expression library. The larger the capacity, the more precise result 
we get. 
"""