import nltk

nltk.app.concordance()